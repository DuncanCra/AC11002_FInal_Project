/**
 * 
 */
/**
 * @author dunca
 *
 */
module reversi {
}