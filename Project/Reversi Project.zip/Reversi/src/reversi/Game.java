package reversi;
import java.util.Scanner;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileNotFoundException;

/**
 * 
 * @author dunca
 *@version 1
 */
public class Game {
	Reversi_Menu backFunction = new Reversi_Menu();
	private FileReader load;
	private BufferedReader loadBuffer;
	private FileOutputStream saveStream;
	private PrintWriter save;
	
	private String [] [] board = new String [9] [9];
	private int BlackScore;
	private int WhiteScore;
	private boolean player = true;
	private int counter;
	/*
	 * method to initlize playing board when user starts a new game 
	 */
	public void InitilizeBoard() {
		 // 2-D array to store the playing board
		for (int row=0; row<9; row++) { // initilizes scale on y axis
			for (int col=0; col<9; col++) {
				if (row ==0) {
					for (col=0; col<9; col++) {
						if (col == 0)
							board [row] [col] = "/";
						else 
							board [row] [col] = String.valueOf(col);
					}	
				}
				else if ((row == 1) && (col ==0)) //inilizes scale on x axis
					board [row] [col] =  "A " ;
				else if ((row ==2) && (col==0))
					board [row] [col] = "B ";
				else if ((row ==3) && (col==0))
					board [row] [col] = "C ";
				else if ((row ==4) && (col==0))
					board [row] [col] = "D ";
				else if ((row ==5) && (col==0))
					board [row] [col] = "E ";
				else if ((row ==6) && (col==0))
					board [row] [col] = "F ";
				else if ((row ==7) && (col==0))
					board [row] [col] = "G ";
				else if ((row ==8) && (col==0))
					board [row] [col] = "H ";
				
				else if ((row==4)&& (col==4)) //initlizes board and playing pieces
					board [row] [col] = "W|";
				 else if ((row==4) && (col==5)) 
					board [row] [col] = "B|";
				 else if ((row==5) && (col==4))
					 board [row] [col] = "B|";
				 else if ((row ==5) && (col==5))
					 board [row] [col] = "W|";
				 else board [row] [col] = "_|";
			}
		}
		counter = 4;
		BlackScore = 2; // sets the starting scores for both players
		WhiteScore = 2;
		displayBoard();		
	} 
	 /**
	  * method to display the playing board in its current state
	  */
	public void displayBoard() {
		
		if (player == true)
			System.out.print("Black's Turn");
		else if (player == false)
			System.out.print("Whites's Turn");
		System.out.println("\t Turn: " + (counter-3));
		System.out.println("Black: " + BlackScore + " \t White: " + WhiteScore); // displays scores of both players
		for (int y=0; y<9; y++) { //displays initlized board
			for (int x=0; x<9; x++) 
				System.out.print(board [x] [y] + " "); // displays 2D array containing playibg board
			System.out.println("");
		}
		if (counter == 64) {
			if (BlackScore > WhiteScore)
				System.out.println("Black Player won with a score of " + BlackScore);
			else if (BlackScore < WhiteScore)
					System.out.println("White Player won with a score of " + WhiteScore);
			else System.out.println("The game was a draw. Both players scored " + BlackScore);
			
			try  {
				saveStream = new FileOutputStream("High_Scores.txt");
				save = new PrintWriter(saveStream);
				save.println(BlackScore);
				save.println(WhiteScore);
				save.close();
			}
			catch (IOException e){
				System.out.println("could not save high score");
			}
			backFunction.displayMenu();
		}
				
	}
	/**
	 * Mmethod to ask user to make a move, and update the playing board
	 */
	
	public void makeMove() {
		Scanner in_x = new Scanner(System.in);
		Scanner in_y = new Scanner (System.in);
		String letter;
		int x = 9;
		int y;
		
		for ( ; counter<64;) { // asks the user to enter the co-ordinate of the square they wish to play their peice on
			System.out.println("Please enter the X-co-ordinate (Capital letter). You may also enter Save to save or Menu to return to menu");
			letter = in_x.nextLine();
			if  (letter.equals("Save")) {
				SaveGame();
				backFunction.displayMenu();
				break;
			}
			else if (letter.equals("Menu")) {
				backFunction.displayMenu();
				break;
			}
			System.out.println("Please enter the Y co-ordinate (number)");
			y = in_y.nextInt();
			
			
			if (letter.equals("A")) // changes the letter input to an integer for use in the 2d array
				x = 1;
			else if (letter.equals("B"))
				x = 2;
			else if (letter.equals("C"))
				x = 3;
			else if (letter.equals("D"))
				x = 4;
			else if (letter.equals("E"))
				x = 5;
			else if (letter.equals("F"))
				x = 6;
			else if (letter.equals("G"))
				x = 7;
			else if (letter.equals("H"))
				x = 8;
			else x = 9;
			
			if ((x >=9) || (y >= 9)) {
				 System.out.println("Invalid co-ordinate - Try Again"); // error message if user inputs co-ordiante outside playing board
				 counter = counter -1;
			 }
				else if ((board [x] [y] != "_|")) {
					System.out.println("Invalid Move - Try Again"); // error message if user inputs an already occupied co-ordinate
					counter = counter -1;
				}
				else if (player == true) { // places black counter, adds point to black score, changes player  to white
					board [x] [y] = "B|";
					BlackScore ++;
					player = false;
				}
				else if (player == false) { // places white counter, adds point to white score, changes player to black
					board [x] [y] = "W|";
					WhiteScore ++;
					player = true;
				}	
		counter++;
		displayBoard();
	}
	}
	
	/**
	 * method to display a saved game from a file
	 */
	public void LoadGame() {
		String number;
		System.out.println("you chose to load a game");
		try {
			load = new FileReader("Save File.txt"); // file to read save data from
			loadBuffer = new BufferedReader(load);
			number = loadBuffer.readLine(); 
			BlackScore = Integer.parseInt(number); // reads Black Score from file and displays it
			number = loadBuffer.readLine();
			WhiteScore = Integer.parseInt(number); // reads White Score from file and displays it
			number = loadBuffer.readLine();
			counter = Integer.parseInt(number); // reads turn counter from file and displays it
			number = loadBuffer.readLine(); // checks players turn 
			if (number.equals("Black"))
				player = true;
			else if (number.equals("White"))
				player = false;
			
			for (int row=0; row<9; row++) { // changes blank spaces and playing peices to string 
				for (int col=0; col<9; col++) {
					number = loadBuffer.readLine();
					if (number.equals("_|"))
						board [row] [col] = "_|";
					else if (number.equals("B|"))
						board [row] [col] = "B|";
					else if (number.equals("W|"))
						board [row] [col] = "W|";
					else 
						board [row] [col] = number;
				}
			}
			displayBoard();
			makeMove();
		}
		
		catch (IOException e) {
			System.out.println("the file was not loaded");
		}
		
	}
	
	/**
	 * method to save game when input is entered
	 */
	public void SaveGame() {
		try {
		saveStream = new FileOutputStream("Save File.txt");
		save = new PrintWriter(saveStream);
			save.println(BlackScore); // saves Black Score to file
			save.println(WhiteScore); // saves White Score to file
			save.println(counter); // Saves turn counter to file
			if (player == true)
				save.println("Black"); // saves players turn to file
			else if (player == false)
				save.println("White");
			for (int x=0; x<9; x++) { //writes current board to file
				for (int y=0; y<9; y++) {
					if (board [x] [y] == "_|") 
						save.println("_|");
					else if (board [x] [y] == "B|") 
						save.println("B|");
					else if (board [x] [y] == "W|")
						save.println("W|");
					else 
						save.println(board [x] [y]);
				}
			}
			System.out.println("The game was sucesffully saved, you may now quit the application");
			save.close();
		}
		catch(IOException e) {
			System.out.println("the file was not saved");
		} 
		
	}
	
	/**
	 * method to display high scores when input is entered
	 */
	public void HighScores() {
		String BScore;
		String WScore;
		Scanner back = new Scanner(System.in);
		try {
			load = new FileReader("High_Scores.txt"); // file to read save data from
			loadBuffer = new BufferedReader(load);
			System.out.println("you chose to view the high scores"); // text to display
			BScore = loadBuffer.readLine();
			WScore = loadBuffer.readLine();
			System.out.println("Black Score: " + BScore + " White Score: " + WScore);
			load.close();
			back.nextLine(); //returns to main menu when any input is entered
			backFunction.displayMenu();
		}
		catch (IOException e) {
		System.out.println("High Scores could not be displayed");
		}
	}
	
	/**
	 * method to display rules of reversi when input is entered
	 */
	public void Rules() {
		Scanner back = new Scanner(System.in);
		System.out.println("1.  There are two players; Black and White");
		System.out.println("2.  Each player starts with two peices in the middle of the board"); // text to display
		System.out.println("3.  You place a piece by entering the appropirtate grid co-ordinate");
		System.out.println("4.  You may only place a peice where it forms a straight line (vertical, horizontal, or diagonal) with another one of your peices");
		System.out.println("5.  Any of your opponents peices that lie between your two peices become yours");
		System.out.println("6.  Play continues untill all spaces on the board are occupied");
		System.out.println("7.  The winner is the player with the most peices when the game ends");
		System.out.println("==================================================================================================================================");
		System.out.println("Press Enter to return to main menu");
		back.nextLine(); // returns to main menu when any input is entered
		backFunction.displayMenu();
	}
	
}
