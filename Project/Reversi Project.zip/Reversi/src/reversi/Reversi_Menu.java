package reversi;
import java.util.Scanner;

/**
 * 
 * @author dunca
 * @version 1
 */
public class Reversi_Menu {

	/**
	 * method to display menu and either start a new game or load a saved one 
	 */
	public void displayMenu( ) {
		Game GameMenu = new Game();
		String choice;
		boolean loop = true;
		System.out.println("Please choose an option below (please note options are case sensitive)"); //asks the uses for input
		System.out.println("New Game");
		System.out.println("Load Game");
		System.out.println("High Scores");
		System.out.println("Rules");
		System.out.println("Quit");
		
		while (loop == true) { // launches new or saved game depending on users input, or loops if no vaild input is detected
			Scanner option = new Scanner(System.in);
			choice = option.nextLine();
			if (choice.equals("New Game")) {
				GameMenu.InitilizeBoard();
				GameMenu.makeMove();
				loop = false;
			} 
			else if (choice.equals("Load Game")) {
				GameMenu.LoadGame();
				loop = false;
			}
			else if (choice.equals("High Scores")) {
				GameMenu.HighScores();
				loop = false;
			}
			else if (choice.equals("Rules")) {
				GameMenu.Rules();
				loop = false;
			}
			else if (choice.equals("Quit")) {
				System.out.println("You have quit the application");
				loop = false;
			}
			else 
				System.out.println("you failed to choose an option");
			}
		}
	
	public static void main(String [] args) { // standard main method
		Reversi_Menu Menu = new Reversi_Menu();
		Menu.displayMenu();
	}
}
		
